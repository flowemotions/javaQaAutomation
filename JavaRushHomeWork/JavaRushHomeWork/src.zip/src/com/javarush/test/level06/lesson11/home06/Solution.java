package com.javarush.test.level06.lesson11.home06;

/* KissMyShinyMetalAss
Создай класс с именем KissMyShinyMetalAss. Создай объект этого класса, выведи его на экран.
*/

public class Solution
{
    public static void main(String[] args)
    {
        KissMyShinyMetalAss kissMyShinyMetalAss = new KissMyShinyMetalAss();
        System.out.println(kissMyShinyMetalAss);
    }

    public static class KissMyShinyMetalAss
    {

    }

}
