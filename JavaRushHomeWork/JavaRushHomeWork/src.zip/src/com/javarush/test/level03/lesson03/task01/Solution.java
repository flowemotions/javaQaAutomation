package com.javarush.test.level03.lesson03.task01;

/* Реализация метода
Добавьте метод public static void printString(String s) который будет выводить переданную строку на экран.
*/
public class Solution
{
    public static void printString(String s)
    {
        System.out.println(s);
    }

    public static void main(String[] args) {
        printString("Hello Amigo!");
    }
}
