package com.javarush.test.level03.lesson04.task01;

/* Дата рождения
Вывести на экран дату своего рождения в виде: MAY 1 2012
*/

public class Solution
{
    public static void main(String[] args)
    {
        System.out.print("MAY");
        System.out.print(" ");
        System.out.print(1);
        System.out.print(" ");
        System.out.print(2012);
    }
}