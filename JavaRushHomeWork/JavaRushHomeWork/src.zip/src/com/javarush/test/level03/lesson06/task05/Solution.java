package com.javarush.test.level03.lesson06.task05;

/* Изучаем японский
Выведи на экран 日本語
*/

public class Solution
{
    public static void main(String[] args)
    {
        System.out.println("日本語");
    }
}